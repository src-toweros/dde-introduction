<a name="1.1.8"></a>
### 1.1.8 (2019-05-29)




<a name="1.1.7"></a>
### 1.1.7 (2019-04-10)




<a name="1.1.6"></a>
### 1.1.6 (2019-03-06)




<a name=""></a>
##  1.1.5 (2019-01-16)


#### Features

*   difference between professional & community ([30a16f44](https://github.com/linuxdeepin/dde-introduction/commit/30a16f44106fd442259dc3706befef1831b3b6d8))



<a name="1.1.4"></a>
### 1.1.4 (2019-01-16)


#### Features

*   difference between professional & community ([30a16f44](https://github.com/linuxdeepin/dde-introduction/commit/30a16f44106fd442259dc3706befef1831b3b6d8))



<a name="1.1.3"></a>
### 1.1.3 (2019-01-07)


#### Features

*   update video and ass for 15.9 ([ccfa7415](https://github.com/linuxdeepin/dde-introduction/commit/ccfa74150fdd40141ceba0523fa7bc7315014efc))



<a name="1.1.2"></a>
### 1.1.2 (2018-12-28)


#### Bug Fixes

*   update wmswitcher interface ([93a43fb3](https://github.com/linuxdeepin/dde-introduction/commit/93a43fb3e649e0dd64586cf9a028ecde8b7e6f25))



<a name="1.1.1"></a>
### 1.1.1 (2018-12-26)


#### Features

*   update all video and ass ([ac7db5e5](https://github.com/linuxdeepin/dde-introduction/commit/ac7db5e5d6d04f746c0a4cf14f193d0111ec9c6b))



<a name=""></a>
##  1.1.0 (2018-12-19)


#### Bug Fixes

*   ass path error ([297ed537](https://github.com/linuxdeepin/dde-introduction/commit/297ed537470dd8c1f1b489f068681fa367ba9c38))



<a name="1.0.10"></a>
### 1.0.10 (2018-12-18)


#### Bug Fixes

*   video path wrong ([49b34d32](https://github.com/linuxdeepin/dde-introduction/commit/49b34d32d2a231b0c54252e544b7af88b01c20f3))



<a name="1.0.9"></a>
### 1.0.9 (2018-12-17)


#### Features

*   add professional video ([3c6b6179](https://github.com/linuxdeepin/dde-introduction/commit/3c6b61798a62e6204b47035614cd078d4be59829))



<a name="1.0.8"></a>
### 1.0.8 (2018-11-28)


#### Features

*   add genericName ([7b2bb229](https://github.com/linuxdeepin/dde-introduction/commit/7b2bb2290caec677370a48668bf079ad89781312))



<a name="1.0.7"></a>
### 1.0.7 (2018-11-12)


#### Features

*   upload 15.8 demo file ([27d7ba50](https://github.com/linuxdeepin/dde-introduction/commit/27d7ba5072993167945d0f0779c1d32613ca8bb5))
*   disable force raster widgets ([fbff6e5a](https://github.com/linuxdeepin/dde-introduction/commit/fbff6e5a81d343ba9b0fefa9fd6678a61c1a212d))



<a name="1.0.6"></a>
### 1.0.6 (2018-08-14)


#### Features

*   update new ass file ([76019f60](https://github.com/linuxdeepin/dde-introduction/commit/76019f602f3ae0c308d3f17161edfec3bd17ea31))



<a name="1.0.5"></a>
### 1.0.5 (2018-08-08)


#### Bug Fixes

*   select icon pos error ([1ac9ff62](https://github.com/linuxdeepin/dde-introduction/commit/1ac9ff625ad17b1aa340a481e3b7e223e6118575))

#### Features

* **video:**  use subtitle ([93540bad](https://github.com/linuxdeepin/dde-introduction/commit/93540bada157a15035de56283551874ffb17c140))



<a name="1.0.4"></a>
### 1.0.4 (2018-07-19)


#### Bug Fixes

*   video file rename ([babb5854](https://github.com/linuxdeepin/dde-introduction/commit/babb5854df3f78799d2abfb3201712044c48505c))



<a name="1.0.3"></a>
### 1.0.3 (2018-06-27)


#### Features

* **pro:**  open deepin.com ([e7430974](https://github.com/linuxdeepin/dde-introduction/commit/e7430974b44b4102b087b23e653ae572b06941b8))



<a name="1.0.2"></a>
### 1.0.2 (2018-06-20)


#### Features

* **pro:**  custom fuction ([836cdc85](https://github.com/linuxdeepin/dde-introduction/commit/836cdc85f861418bbc4205a1394f91ac2c0378c3))



<a name="1.0.1"></a>
### 1.0.1 (2018-06-07)


#### Bug Fixes

*   cannot use alt+f4 close window ([b6619b80](https://github.com/linuxdeepin/dde-introduction/commit/b6619b80115eb0d8f73e559c4f0fde1ec1682c7b))
*   error app name ([89593643](https://github.com/linuxdeepin/dde-introduction/commit/89593643ec4e379ec4a841a713a315bf530ea2d8))
* **video:**  video jitter ([35776c30](https://github.com/linuxdeepin/dde-introduction/commit/35776c30aae781368b9e3c50458cfc26cd86f1fe))

#### Features

*   upload new video for english ([76898fe7](https://github.com/linuxdeepin/dde-introduction/commit/76898fe7109186371894735231f1a8b8b5b19e71))



<a name=""></a>
##  1.0.0 (2018-05-29)


#### Features

*   upload 15.6 demo video ([d0b0f53b](https://github.com/linuxdeepin/dde-introduction/commit/d0b0f53b5365f7d32c4b89cace10486e9d9e9711))



<a name="0.0.3"></a>
### 0.0.3 (2018-05-24)




<a name="0.0.2"></a>
### 0.0.2 (2018-05-23)


#### Features

*   add done button ([b756188b](https://github.com/linuxdeepin/dde-introduction/commit/b756188beeb699033b4ab19f2a04bd0665479f78))
*   check support switch wm ([0dd291df](https://github.com/linuxdeepin/dde-introduction/commit/0dd291df4f37a283a724c07d800fcd09e4f476a6))
*   video support button animation ([c6d77481](https://github.com/linuxdeepin/dde-introduction/commit/c6d77481dee10faabbb65fc12c1beacf26cd4aca))
* **icon:**
  *  set vertical spacing ([c61df69e](https://github.com/linuxdeepin/dde-introduction/commit/c61df69eeb58e32fb787a76875bcc1c3a0ae0ab4))
  *  sort icon list ([cfd9b3c4](https://github.com/linuxdeepin/dde-introduction/commit/cfd9b3c44cd7a5168b2b0060dbf356ed5ae026d1))
* **video:**
  *  update new video file ([17eadc7d](https://github.com/linuxdeepin/dde-introduction/commit/17eadc7d0f2217ba6ca5509896062a5d4b395276))
  *  support hide control animation ([7833efd9](https://github.com/linuxdeepin/dde-introduction/commit/7833efd90fe35e0d95fce4b86e3f84ed4031d3ea))
  *  update new control icon ([feb5298e](https://github.com/linuxdeepin/dde-introduction/commit/feb5298eaec5ccf6b64019a387bcf837f6ebb7ff))
  *  pause video when stop ([ba6cfa4f](https://github.com/linuxdeepin/dde-introduction/commit/ba6cfa4fb56e87ea9436829ef808947ba1b7b475))

#### Bug Fixes

*   done button not have focus ([2cd5b87d](https://github.com/linuxdeepin/dde-introduction/commit/2cd5b87d9a9fa113bec14ee02156e634a4c7be40))
*   not load ts ([c49e3a0e](https://github.com/linuxdeepin/dde-introduction/commit/c49e3a0e9398600c3a4b0f70508cea68a0f197cf))
*   empty page when cannot switch wm ([5b39af1a](https://github.com/linuxdeepin/dde-introduction/commit/5b39af1a2cc56df91515a1eb4711222d381bd9a0))
*   normal window icon error ([b3a5284a](https://github.com/linuxdeepin/dde-introduction/commit/b3a5284a45e4e65d688a9efb331c3da0f902b0cd))
*   button link ([b5303cc1](https://github.com/linuxdeepin/dde-introduction/commit/b5303cc1c35b2cd3a4f9ba0889facce2cd01d899))
*   button shift after rolling ([ce46befc](https://github.com/linuxdeepin/dde-introduction/commit/ce46befc26f346f1546622318c64016e1b104715))
*   border truncation ([1c4bda8e](https://github.com/linuxdeepin/dde-introduction/commit/1c4bda8ea932dc73bb15623c6eeb5dd5fed2c3c8))
*   desktop mode error ([ffc63571](https://github.com/linuxdeepin/dde-introduction/commit/ffc63571c5944cca55885b79cd70b351232b9c30))
* **icon:**  not align center ([f22acf74](https://github.com/linuxdeepin/dde-introduction/commit/f22acf7468444d9718424f3b48f894c18cbde174))
* **video:**  block key event ([6543eac7](https://github.com/linuxdeepin/dde-introduction/commit/6543eac7ece5ea7c507510085333adc2d8d60b42))



<a name=""></a>
##  0.0.1 (2018-04-24)


#### Features

*   set cursor for bottom navigation ([555edec0](https://github.com/linuxdeepin/dde-introduction/commit/555edec0a92f7b962c2d26e5426e40b573bf528e))
*   save the config ([ef47678f](https://github.com/linuxdeepin/dde-introduction/commit/ef47678f939b29919f9cdb3476d2fa9888379aab))
*   add title label to normal module & auto hide control btn ([ea048392](https://github.com/linuxdeepin/dde-introduction/commit/ea0483927dbf320ad0c4a223e14df24b5116b69c))
*   add previous button ([a3e22de6](https://github.com/linuxdeepin/dde-introduction/commit/a3e22de6c98b2cf98c267283b4346ebea8499f26))
*   normal window ([ea2d4767](https://github.com/linuxdeepin/dde-introduction/commit/ea2d4767d29a101d98c339b816edfcdae22ae398))
*   add navigation button ([b4a54bf3](https://github.com/linuxdeepin/dde-introduction/commit/b4a54bf32438a3eee18975e46632bd9e3e653518))
*   add base Normal window ([1dba9944](https://github.com/linuxdeepin/dde-introduction/commit/1dba99447597c5d4438a8fa08e19065535bc15e3))
*   support HiDPI ([a3fcf559](https://github.com/linuxdeepin/dde-introduction/commit/a3fcf5597390e7de22390e30607f4a69e8457bd0))
*   module use resources ([424710e0](https://github.com/linuxdeepin/dde-introduction/commit/424710e0f3f2bc71cbd5858f17de405f35672a16))
*   add resources ([9c772a97](https://github.com/linuxdeepin/dde-introduction/commit/9c772a97e63d205a5162b5e6fce12f1c8c99fa7b))
*   add icon module ([d3a82f38](https://github.com/linuxdeepin/dde-introduction/commit/d3a82f380d29fdc86841a8cf544b169c27e23a34))
*   add icon thumbnail ([4bc2a101](https://github.com/linuxdeepin/dde-introduction/commit/4bc2a101febf4c1edeafde383482d4b26f02ebc1))
*   add wm mode module ([7f981a66](https://github.com/linuxdeepin/dde-introduction/commit/7f981a664f88bdafaa99900f1d5a8b6e7720a444))
*   add base module widget ([d6c3f477](https://github.com/linuxdeepin/dde-introduction/commit/d6c3f477545921d36140e6240341e69cc4060032))
*   add desktop mode module ([ece3fdc6](https://github.com/linuxdeepin/dde-introduction/commit/ece3fdc6f80eaa2737483fec4c456745df93cca5))
*   add wm and desktop type to model ([bf50d542](https://github.com/linuxdeepin/dde-introduction/commit/bf50d5425274ae14900eac658b371dcd57294109))
*   add base model ([ca2ac656](https://github.com/linuxdeepin/dde-introduction/commit/ca2ac6563093efcb32f5b42498e230d2bea4070c))
*   add base worker ([013ef25c](https://github.com/linuxdeepin/dde-introduction/commit/013ef25c113667bdce3a292f49f945db30219f47))
*   add base widget ([330ee995](https://github.com/linuxdeepin/dde-introduction/commit/330ee9959767b02b82f7fe7e55ff9e6fcba7c40b))
*   add borderwidget ([855d9808](https://github.com/linuxdeepin/dde-introduction/commit/855d98089987638e260fe34efba25e7ba9ac2661))
*   add videowidget ([48edc986](https://github.com/linuxdeepin/dde-introduction/commit/48edc9860c93425e8808ffaccc355cfeaa19c5bc))
*   add base switch and animation ([9998b9ea](https://github.com/linuxdeepin/dde-introduction/commit/9998b9eadb52a1fc8ef7f44262e430126b2b823c))
*   add switch button ([ad5ed0e6](https://github.com/linuxdeepin/dde-introduction/commit/ad5ed0e619deebd3ac6ad3be6c2f0395c6dd7686))
*   set application base infos ([6701186c](https://github.com/linuxdeepin/dde-introduction/commit/6701186c855e036b75705deffac72b0464a458e5))
*   add desktop file. ([e985fc24](https://github.com/linuxdeepin/dde-introduction/commit/e985fc244d0a31c7c7af5d0590332e3216030a82))
* **NormalWindow:**  use DDialog instead of DSettingsDialog. ([adbd0d46](https://github.com/linuxdeepin/dde-introduction/commit/adbd0d46bffdcf25677fbfd6e04eb75112522d63))
* **module:**  init video module ([fb73676a](https://github.com/linuxdeepin/dde-introduction/commit/fb73676a2bbb248e259d37733d789b3d140d17a6))

#### Bug Fixes

*   typo ([88707e07](https://github.com/linuxdeepin/dde-introduction/commit/88707e072fc5dff69b42944e256ec3cfb9cfd485))
*   canot set icon ([71b2b543](https://github.com/linuxdeepin/dde-introduction/commit/71b2b5431a25526af97d62c3bf75856a44970a3a))
*   not set video pixel ratio ([294f1f2b](https://github.com/linuxdeepin/dde-introduction/commit/294f1f2bd02e0a2dd48e54d35ad44cb4e03b537f))
*   bottom navigation not align ([e0d18df0](https://github.com/linuxdeepin/dde-introduction/commit/e0d18df0a7a07695f96a62c41703d7b99437dd03))
*   videowidget missing macro ([a46498d8](https://github.com/linuxdeepin/dde-introduction/commit/a46498d83d61e875b67c63c1b297ee99692d1fc3))



