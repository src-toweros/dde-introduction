#/bin/bash

PROFESSIONAL_VIDEO_PATH=./resources/video/professional.mp4
COMMUNITY_VIDEO_PATH=./resources/video/community.mp4
SERVER_VIDEO_PATH=./resources/video/server.mp4

SYS_INFO=`cat /etc/deepin-version | grep Type= | cut -d '=' -f 2`

if [ $SYS_INFO == "Community" ]; then
    rm $PROFESSIONAL_VIDEO_PATH
    rm $SERVER_VIDEO_PATH
elif [ $SYS_INFO == "Server" ]; then
    rm $PROFESSIONAL_VIDEO_PATH
    rm $COMMUNITY_VIDEO_PATH
else
    rm $SERVER_VIDEO_PATH
    rm $COMMUNITY_VIDEO_PATH
fi
       



