<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation>Comunidade</translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation>Opinião</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation>Agradecimentos</translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation>Modo Eficiente</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation>Modo Elegante</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Concluído</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Escolha um modo de ambiente de trabalho</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Pode alternar os modos ao clicar com o botão direito do rato na doca</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Escolha um modo de funcionamento</translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation>Pode alterar no Centro de Controlo &gt; Personalização &gt; Efeitos visuais</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Escolha um tema de ícones</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Alterar no Centro de Controlo &gt; Personalização &gt; Tema de ícones</translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation>Introdução</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Bem-vindo</translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation>Modo de ambiente de trabalho</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Escolha um modo de ambiente de trabalho</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Pode alternar os modos ao clicar com o botão direito do rato na doca</translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation>Modo de funcionamento</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Escolha um modo de funcionamento</translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation>Escolha o modo normal se tem um computador de configuração fraca</translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation>Tema de ícones</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Escolha um tema de ícones</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Alterar no Centro de Controlo &gt; Personalização &gt; Tema de ícones</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation>Bem-vindo</translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation>Modo normal</translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation>Modo de efeitos</translation>
    </message>
</context>
</TS>