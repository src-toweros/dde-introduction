<?xml version="1.0" ?><!DOCTYPE TS><TS language="it" version="2.1">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation>Community</translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation>Feeback</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation>Considerazioni</translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation>Efficient</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation>Fashion</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Fatto</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Scegli la modalità desktop</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Potrete modificare la modalità cliccando col tasto destro sulla Dock</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Scegli una modalità di esecuzione</translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation>Potrete modificarlo nel Control Center &gt; Personalizzazione &gt; Effetti finestre</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Scegli un tema per le icone</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Potrete modificarlo nel Control Center &gt; Personalizzazione &gt; Tema icone</translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation>Introduzione</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Benvenuto</translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation>Modalità desktop</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Scegli una modalità desktop</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Potrete modificare la modalità cliccando col tasto destro sulla Dock</translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation>Modalità in esecuzione</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Scegli una modalità di esecuzione</translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation>Seleziona la modalità base se hai una configurazione hardware basilare</translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation>Tema icone</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Scegli un tema per le icone</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Potrete modificarlo nel Control Center &gt; Personalizzazione &gt; Tema icone</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation>Benvenuto</translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation>Modalità Base</translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation>Modalità Completa</translation>
    </message>
</context>
</TS>