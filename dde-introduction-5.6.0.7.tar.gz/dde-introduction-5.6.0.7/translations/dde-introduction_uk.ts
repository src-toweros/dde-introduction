<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation>Спільнота</translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation>Відгуки</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation>Відомості</translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation>Режим ефективності</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation>Модний режим</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation>Наступний</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Виберіть режим стільниці</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Перемикати режими можна клацанням правою кнопкою на бічній панелі</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Виберіть режим роботи</translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation>Його можна перемкнути за допомогою пункту «Центр керування &gt; Персоналізація &gt; Ефект вікон»</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Вибір теми піктограм</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Ви можете змінити її за допомогою пункту «Центр керування &gt; Персоналізація &gt; Тема піктограм»</translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation>Вступ</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Вітаємо</translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation>Режим стільниці</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Виберіть режим стільниці</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Перемикати режими можна клацанням правою кнопкою на бічній панелі</translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation>Режим роботи</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Виберіть режим роботи</translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation>Будь ласка, виберіть звичайний режим, якщо ви працюєте із не дуже потужним комп&apos;ютером</translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation>Тема Значка</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Вибір теми піктограм</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Ви можете змінити її за допомогою пункту «Центр керування &gt; Персоналізація &gt; Тема піктограм»</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation>Вітаємо</translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation>Звичайний режим</translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation>Режим ефекту</translation>
    </message>
</context>
</TS>