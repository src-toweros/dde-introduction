<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" version="2.1">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation>Заједница</translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation>Повратне инфорнмације</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Помоћ</translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation>Заслуге</translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation>Ефикасан режим</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation>Улицкан режим</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation>Следеће</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Изабери режим дока</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Можете мењати режиме десним кликом на док</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Изабери режим рада</translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation>Можете променити у Контролни Центар &gt; Личне промене &gt; Ефекти прозора</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Изабери тему иконица</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Можете променити у Контролни Центар &gt; Личне промене &gt; Тема иконица</translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation>Упознај</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Добро дошли</translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation>Режим дока</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Изабери режим дока</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Можете мењати режиме десним кликом на док</translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation>Режим рада</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Изабери режим рада</translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation>Изаберите обичан режим ако је рачунар слабијих могућности</translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation>Тема иконица</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Изабери тему иконица</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Можете променити у Контролни Центар &gt; Личне промене &gt; Тема иконица</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation>Добро дошли</translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation>Обичан режим</translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation>Режим ефеката</translation>
    </message>
</context>
</TS>