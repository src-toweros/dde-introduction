<?xml version="1.0" ?><!DOCTYPE TS><TS language="vi" version="2.1">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation>Cộng đồng</translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation>Phản hồi</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Giúp đỡ</translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation>Ghi nhận</translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation>Chế độ Hiệu quả</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation>Chế độ Thời trang</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation>Kế tiếp</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Xong</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Chọn chế độ hiển thị màn hình</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Bạn có thể chuyển đổi chế độ bằng cách nhấp chuột phải vào thanh công cụ</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Chọn chế độ chạy</translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation>Bạn có thể chuyển nó trong Trung tâm điều khiển&gt; Cá nhân hóa&gt; Hiệu ứng cửa sổ</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Chọn một chủ đề icon</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Thay đổi nó trong Trung tâm điều khiển&gt; Cá nhân hóa&gt; Chủ đề icon</translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation>Giới thiệu</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Xin chào</translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation>Chế độ Desktop</translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation>Chọn chế độ hiển thị màn hình</translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation>Bạn có thể chuyển đổi chế độ bằng cách nhấp chuột phải vào thanh công cụ</translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation>Chế độ chạy</translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation>Chọn chế độ chạy</translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation>Vui lòng chọn chế độ bình thường nếu bạn có máy tính cấu hình thấp</translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation>Chủ đề Biểu tượng</translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation>Chọn một chủ đề icon</translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation>Thay đổi nó trong Trung tâm điều khiển&gt; Cá nhân hóa&gt; Chủ đề icon</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation>Xin chào</translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation>Chế độ bình thường</translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation>Chế độ Hiệu quả</translation>
    </message>
</context>
</TS>