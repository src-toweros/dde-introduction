<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>BottomNavigation</name>
    <message>
        <source>Community</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feeback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acknowledgments</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DesktopModeModule</name>
    <message>
        <source>Efficient Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can switch it in Control Center &gt; Personalization &gt; Window effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NormalModule</name>
    <message>
        <source>Introduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desktop Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a desktop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can switch modes by right clicking on the dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a running mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please choose normal mode if you has a low configuration computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose an icon theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change it in Control Center &gt; Personalization &gt; Icon Theme</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WMModeModule</name>
    <message>
        <source>Normal Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Effect Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
